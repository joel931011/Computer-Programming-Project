#include "LTexture.h"
#include <iostream>

LTexture::LTexture()
{
    // ��l��
    mTexture = NULL;
    mWidth = 0;
    mHeight = 0;
}

LTexture::~LTexture()
{
    // ����P���ɽT�O����귽
    free();
}

bool LTexture::loadFromFile( std::string path, SDL_Renderer* renderer )
{
    // �p�G�쥻�����z�A������
    free();

    // �̲ת����z
    SDL_Texture* newTexture = NULL;

    // --- ����ק�G�۰ʥ[�W img/ ���| ---
    std::string fullPath = "/Users/yijhuowei/1216/img/" + path;
    // �o�˧A�b main �̼g "player.png"�A�o�̷|Ū�� "img/player.png"

    // ���J�Ϥ��� Surface
    SDL_Surface* loadedSurface = IMG_Load( fullPath.c_str() );
    if( loadedSurface == NULL )
    {
        printf( "Unable to load image %s! SDL_image Error: %s\n", fullPath.c_str(), IMG_GetError() );
    }
    else
    {
        // �]�w Color Key (�h�I)
        // �o��q�`�Ω� BMP �ΨS���z���q�D���ϡA�N�u�C�� (0,255,255)�v�]���z��
        // �p�G�A�Ϊ��O PNG �B�������z���I���A�o����D���n�A���d�۵L��
        SDL_SetColorKey( loadedSurface, SDL_TRUE, SDL_MapRGB( loadedSurface->format, 0, 0xFF, 0xFF ) );

        // �q Surface �إ� Texture
        newTexture = SDL_CreateTextureFromSurface( renderer, loadedSurface );
        if( newTexture == NULL )
        {
            printf( "Unable to create texture from %s! SDL Error: %s\n", fullPath.c_str(), SDL_GetError() );
        }
        else
        {
            // ���o�Ϥ��ؤo
            mWidth = loadedSurface->w;
            mHeight = loadedSurface->h;
        }

        // ����Ȧs�� Surface
        SDL_FreeSurface( loadedSurface );
    }

    // �^�Ǧ��\�P�_
    mTexture = newTexture;
    return mTexture != NULL;
}

bool LTexture::loadFromRenderedText( std::string textureText, SDL_Color textColor, TTF_Font* font, SDL_Renderer* renderer )
{
    // �������ª�
    free();

    // ��V��r Surface
    SDL_Surface* textSurface = TTF_RenderUTF8_Blended( font, textureText.c_str(), textColor );
    if( textSurface == NULL )
    {
        printf( "Unable to render text surface! SDL_ttf Error: %s\n", TTF_GetError() );
    }
    else
    {
        // �q Surface �إ� Texture
        mTexture = SDL_CreateTextureFromSurface( renderer, textSurface );
        if( mTexture == NULL )
        {
            printf( "Unable to create texture from rendered text! SDL Error: %s\n", SDL_GetError() );
        }
        else
        {
            // ���o��r�Ϥ��ؤo
            mWidth = textSurface->w;
            mHeight = textSurface->h;
        }

        // ���� Surface
        SDL_FreeSurface( textSurface );
    }

    // �^�Ǧ��\�P�_
    return mTexture != NULL;
}

void LTexture::free()
{
    // �p�G���z�s�b�A�h����
    if( mTexture != NULL )
    {
        SDL_DestroyTexture( mTexture );
        mTexture = NULL;
        mWidth = 0;
        mHeight = 0;
    }
}

void LTexture::setColor( Uint8 red, Uint8 green, Uint8 blue )
{
    // �]�w���z���C��Ҳ�
    SDL_SetTextureColorMod( mTexture, red, green, blue );
}

void LTexture::setBlendMode( SDL_BlendMode blending )
{
    // �]�w�V�X�Ҧ�
    SDL_SetTextureBlendMode( mTexture, blending );
}

void LTexture::setAlpha( Uint8 alpha )
{
    // �]�w�z����
    SDL_SetTextureAlphaMod( mTexture, alpha );
}

// 檔案: header/LTexture.cpp

// 這裡的參數必須與 LTexture.h 完全一致（共 9 個），且不可寫預設值（如 = NULL）
void LTexture::render( int x, int y, SDL_Rect* clip, double angle, SDL_Point* center, SDL_RendererFlip flip, SDL_Renderer* renderer, int targetW, int targetH )
{
    // 1. 設定渲染目標矩形，預設為圖片原始大小 mWidth, mHeight
    SDL_Rect renderQuad = { x, y, mWidth, mHeight };

    // 2. 如果有 clip (切割範圍)，優先使用 clip 的大小
    if( clip != NULL )
    {
        renderQuad.w = clip->w;
        renderQuad.h = clip->h;
    }

    // 3. 【關鍵】如果呼叫時有傳入 targetW 或 targetH，強制覆蓋大小 (達成縮放)
    if( targetW != -1 ) renderQuad.w = targetW;
    if( targetH != -1 ) renderQuad.h = targetH;

    // 4. 執行渲染
    // 使用傳進來的參數 renderer。如果呼叫端沒傳(NULL)，則使用全域變數 gRenderer
    if( renderer != NULL )
    {
        SDL_RenderCopyEx( renderer, mTexture, clip, &renderQuad, angle, center, flip );
    }
    else
    {
        // 這是為了相容舊代碼，如果沒傳 renderer 就找全域的
        extern SDL_Renderer* gRenderer;
        SDL_RenderCopyEx( gRenderer, mTexture, clip, &renderQuad, angle, center, flip );
    }
}
int LTexture::getWidth()
{
    return mWidth;
}

int LTexture::getHeight()
{
    return mHeight;
}
