#ifndef BOSS_H
#define BOSS_H

#include "character.h"
#include "bullet.h"
#include <vector>

class Boss : public Character
{
public:
    static const int BOSS_WIDTH = 69;
    static const int BOSS_HEIGHT = 69;

    Boss(int x, int y, LTexture* texture, int bossLevel);

    void move() override;

    // --- 加入這一行 ---
    void render() override;
    // -----------------

    std::vector<Bullet*> fire(LTexture* bulletTexture);
    SDL_Rect getCollider();

    int getLevel() const { return mBossLevel; }

private:
    int mBossLevel;
    int frameCounter;

    enum BossState { ENTERING, FIGHTING };
    BossState state;

    bool movingRight;
};

#endif