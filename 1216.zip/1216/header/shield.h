#ifndef SHIELD_H
#define SHIELD_H

#include <SDL2/SDL.h>
#include "LTexture.h"

// �ޥΥ~���ܼ�
extern LTexture gShieldItemTexture; // �D��b�a�W���Ϥ�
extern const int SCREEN_HEIGHT;

class ShieldItem
{
public:
    // �غc�l (�]�t tutorial �Ϊ� stopAtMiddle)
    ShieldItem(int x, int y, bool stopAtMiddle = false);

    static const int WIDTH = 40;
    static const int HEIGHT = 40;

    void move();
    void render();
    bool isAvailable() const { return available; }
    void setTaken() { available = false; }
    SDL_Rect getCollider();

private:
    int mPosX, mPosY;
    int mVelY;
    bool available;
    bool mStopAtMiddle;
};

#endif
