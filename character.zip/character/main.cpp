#include <SDL2/SDL.h>
#include <SDL2_image/SDL_image.h>
#include <iostream>
#include "header/LTexture.h"
#include "header/character.h"

const int SCREEN_WIDTH = 800;
const int SCREEN_HEIGHT = 600;
const int CHARACTER_SPEED = 5;  // ✨ 速度保持 5

bool init();
bool loadMedia();
void close();

SDL_Window* gWindow = NULL;
SDL_Renderer* gRenderer = NULL;

LTexture gCharacterTexture;        // Front (maincharacter.png)
LTexture gCharacterTextureLeft;    // Left
LTexture gCharacterTextureRight;   // Right

int posX = 400;
int posY = 300;

// ✨ 恢復原本的 Direction 列舉
enum Direction { FRONT, LEFT, RIGHT };
Direction currentDirection = FRONT;

// scale value (0.3 = 30% size)
double charScale = 0.1;

// ... (init, loadMedia, close 函式保持不變) ...

bool init()
{
    if (SDL_Init(SDL_INIT_VIDEO) < 0)
        return false;

    gWindow = SDL_CreateWindow("Character Control",
        SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
        SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);

    if (!gWindow) return false;

    gRenderer = SDL_CreateRenderer(gWindow, -1,
        SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);

    if (!gRenderer) return false;

    // enable PNG with alpha (去背)
    int imgFlags = IMG_INIT_PNG;
    if (!(IMG_Init(imgFlags) & imgFlags))
        return false;

    return true;
}

bool loadMedia()
{
    bool success = true;

    // 請確認三張圖片的像素寬高一致，以避免切換時畫面抖動。
    if (!gCharacterTexture.loadFromFile("/Users/yijhuowei/character/img/maincharacter.png"))
        success = false;

    if (!gCharacterTextureLeft.loadFromFile("/Users/yijhuowei/character/img/maincharacterleft.png"))
        success = false;

    if (!gCharacterTextureRight.loadFromFile("/Users/yijhuowei/character/img/maincharacterright.png"))
        success = false;

    return success;
}

void close()
{
    gCharacterTexture.free();
    gCharacterTextureLeft.free();
    gCharacterTextureRight.free();

    SDL_DestroyRenderer(gRenderer);
    SDL_DestroyWindow(gWindow);
    gRenderer = NULL;
    gWindow = NULL;

    IMG_Quit();
    SDL_Quit();
}


int main(int argc, char* args[])
{
    if (!init())
        return 1;

    if (!loadMedia())
        return 1;

    bool quit = false;
    SDL_Event e;

    // 追蹤是否有水平移動
    bool movingHorizontal = false;

    while (!quit)
    {
        while (SDL_PollEvent(&e))
        {
            if (e.type == SDL_QUIT)
                quit = true;
        }

        const Uint8* state = SDL_GetKeyboardState(NULL);
        movingHorizontal = false; // 重置水平移動狀態

        // movement
        if (state[SDL_SCANCODE_LEFT]) {
            posX -= CHARACTER_SPEED;
            currentDirection = LEFT; // 移動中，設為 LEFT
            movingHorizontal = true;
        }
        // 使用 else if 確保左右不衝突，並且維持了只在移動時變換方向的邏輯
        else if (state[SDL_SCANCODE_RIGHT]) {
            posX += CHARACTER_SPEED;
            currentDirection = RIGHT; // 移動中，設為 RIGHT
            movingHorizontal = true;
        }

        // ✨ 新增邏輯：如果停止水平移動，則將方向設為 FRONT
        if (!movingHorizontal) {
            currentDirection = FRONT;
        }

        // 垂直移動保持不變
        if (state[SDL_SCANCODE_UP])
            posY -= CHARACTER_SPEED;
        if (state[SDL_SCANCODE_DOWN])
            posY += CHARACTER_SPEED;

        // clear screen
        SDL_SetRenderDrawColor(gRenderer, 0, 0, 0, 255);
        SDL_RenderClear(gRenderer);

        // render character
        // ✨ 渲染邏輯：只在 LEFT 或 RIGHT 狀態下使用側面紋理
        if (currentDirection == LEFT)
            gCharacterTextureLeft.render(posX, posY, charScale);
        else if (currentDirection == RIGHT)
            gCharacterTextureRight.render(posX, posY, charScale);
        else // currentDirection == FRONT
            gCharacterTexture.render(posX, posY, charScale);

        SDL_RenderPresent(gRenderer);
    }

    close();
    return 0;
}