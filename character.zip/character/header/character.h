#ifndef CHARACTER_H
#define CHARACTER_H

#include <SDL2/SDL.h>
#include <SDL2_image/SDL_image.h>
#include <stdio.h>
#include <string>
#include "LTexture.h"
#include <vector>
#include <chrono>



extern LTexture gCharacterTexture;
extern LTexture gCharacterTextureLeft;
extern LTexture gCharacterTextureRight;

extern const int SCREEN_WIDTH;
extern const int SCREEN_HEIGHT;

class Bullet;


class Character
{
    public:
  //The dimensions of the character
  	static const int CHARACTER_WIDTH = 60;
  	static const int CHARACTER_HEIGHT = 60;
	enum Direction { LEFT, MID, RIGHT };
	Direction dir = MID;

  //Maximum axis velocity of the character
  	int CHARACTER_VEL;
	void reset();

  //Initializes the variables
  	Character();

  //Takes key presses and adjusts the character's velocity
  	void handleEvent( SDL_Event& e);
	int dot_rate;
  //Moves the character
  	void move();

  //Shows the character on the screen
  	void render();
    std::chrono::time_point<std::chrono::steady_clock> now;
    std::chrono::duration<double> time_dot = std::chrono::duration<double>(1); 
    std::chrono::duration<double> time_interval_dot;
  	int bullet_lv;
  
  	void basic_bullet_initial(int lv);
  	int getPosX() const { return mPosX; }
	int getPosY() const { return mPosY; }
 	int mPosX, mPosY;
 	int health;
   	bool check_bullet_destroy();
    
    bool bullet_collison();
    
    double cal_distance(int x0, int y0, int x1, int y1);
    private:
  	//The X and Y offsets of the character
 
  	//The velocity of the character
  	int mVelX, mVelY;
  
  	int level;

};

#endif
