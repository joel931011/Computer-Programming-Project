#include "character.h"
#include <iostream>
#include <ctime>
#include <cstdlib>  
#include <memory>
#include <cmath>


Character::Character()
{
    //Initialize the offsets
    mPosX = 380;
    mPosY = 430;
    dot_rate = 1;
    CHARACTER_VEL = 1;

    //Initialize the velocity
    mVelX = 0;
    mVelY = 0;
    level = 1;
    health = 20;
    //std::chrono::time_point<std::chrono::steady_clock> now;
    //std::chrono::duration<double> time_dot = std::chrono::duration<double>(1);
    //now = time(NULL);
}

void Character::handleEvent( SDL_Event& e )
{
    //If a key was pressed
 if( e.type == SDL_KEYDOWN && e.key.repeat == 0 )
    {
        //Adjust the velocity
        switch( e.key.keysym.sym )
        {
            case SDLK_UP: mVelY -= CHARACTER_VEL; break;
            case SDLK_DOWN: mVelY += CHARACTER_VEL; break;
            case SDLK_LEFT: mVelX -= CHARACTER_VEL; dir = LEFT; break;
            case SDLK_RIGHT: mVelX += CHARACTER_VEL; dir = RIGHT; break;
            case SDLK_x:
                time_dot = std::chrono::duration<double>(1); 
                break;
        }
    }
    //If a key was released
    else if( e.type == SDL_KEYUP && e.key.repeat == 0 )
    {
        //Adjust the velocity
        switch( e.key.keysym.sym )
        {
            case SDLK_UP: mVelY += CHARACTER_VEL; break;
            case SDLK_DOWN: mVelY -= CHARACTER_VEL; break;
            case SDLK_LEFT: mVelX += CHARACTER_VEL; dir = MID; break;
            case SDLK_RIGHT: mVelX -= CHARACTER_VEL; dir = MID; break;
        }
    }
    /*if( e.key.keysym.sym == SDLK_x){
     dots.emplace_back(mPosX, mPosY);
 }*/

    
}

void Character::move()
{
    //Move the character left or right
    //std::cout<<mPosX << "\t" << mPosY << "\n";
    mPosX += mVelX;
 	//std::cout << mVelX << ' ' << mVelY << '\n'; 
    //If the character went too far to the left or right
    if( ( mPosX < 0 ) || ( mPosX + CHARACTER_WIDTH > SCREEN_WIDTH ) )
    {
        //Move back
        mPosX -= mVelX;
    }

    //Move the character up or down
    mPosY += mVelY;

    //If the character went too far up or down
    if( ( mPosY < 0 ) || ( mPosY + CHARACTER_HEIGHT > SCREEN_HEIGHT ) )
    {
        //Move back
        mPosY -= mVelY;
    }
   
    //dots.emplace_back(mPosX, mPosY)
    auto current_time = std::chrono::steady_clock::now();
    if (current_time - now > time_dot)
    {
        now = current_time;
        
    }
    
    //std::cout << mPosX << ' ' << mPosY << '\n';

}

void Character::reset() {
    // ���m�����m
    mPosX = 380;
    mPosY = 430;
    dot_rate = 1;
    CHARACTER_VEL = 1;

    //Initialize the velocity
    mVelX = 0;
    mVelY = 0;
    level = 1;
    health = 20;

    // �M�Ťl�u

    // ���m�ɶ�����
    time_dot = std::chrono::duration<double>(1);
    now = std::chrono::steady_clock::now();
}


void Character::render()
{
    //Show the character
    switch (dir)
    {
        case LEFT:
            gCharacterTextureLeft.render(mPosX, mPosY);
            break;

        case MID:
            gCharacterTexture.render(mPosX, mPosY);
            break;

        case RIGHT:
            gCharacterTextureRight.render(mPosX, mPosY);
            break;
    }

 
}
