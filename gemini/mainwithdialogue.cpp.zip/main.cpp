/**
 * Main.cpp
 * ��X�G�D���B�ĤH�BBoss�B�D��B�l�u�BUI�B���ġB���A��
 */

#include <SDL2/SDL.h>
#include <SDL2_image/SDL_image.h>
#include <SDL2_ttf/SDL_ttf.h>
#include <SDL2_mixer/SDL_mixer.h>
#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <ctime>
#include <cstdlib>

// �ޤJ�۩w�q���O
#include "header/LTexture.h"
#include "header/player.h"
#include "header/enemy.h"
#include "header/boss.h"
#include "header/bullet.h"
#include "header/magnifier.h"

// --- ����`�� ---
const int SCREEN_WIDTH = 1600;
const int SCREEN_HEIGHT = 900;

// --- �C�����A ---
enum GameState {
    STATE_MENU,
    STATE_INSTRUCTION,
    STATE_PLAYING,
    STATE_GAME_OVER,
    STATE_WIN,
    STATE_DIALOGUE
};

enum LevelStage {
    STAGE_1,
    BOSS_1_FIGHT,
    STAGE_2,
    BOSS_2_FIGHT,
    STAGE_TUTORIAL_INTRO,
    STAGE_TUTORIAL_ENEMY_FIRST,
    STAGE_TUTORIAL_ITEM_FIRST
};
LTexture gDialogueBox;
// --- �����ܼ� (SDL ����) ---
SDL_Window* gWindow = NULL;
SDL_Renderer* gRenderer = NULL;
TTF_Font* gFont = NULL;
// --- �����ܼ� (���z�귽) ---
LTexture gMenuTexture;
LTexture gInstructionTexture;
LTexture gGameOverTexture;
LTexture gWinTexture;
LTexture gBGTexture; // �I����

// ����P�D�㯾�z
LTexture gPlayerFront, gPlayerLeft, gPlayerRight;
LTexture gEnemyTexture1;
LTexture gEnemyTexture2;
LTexture gEnemyTexture3;
LTexture gBossTexture;
LTexture gBulletTexture;      // �D���l�u
LTexture gEnemyBulletTexture; // �ĤH�l�u
LTexture gMagnifierTexture;   // �D��

// UI ���z
LTexture gScoreTextTexture;
LTexture gHealthTextTexture;

// --- �����ܼ� (���ĸ귽) ---
Mix_Music *gMusic = NULL;
Mix_Chunk *gLaserSound = NULL;
Mix_Chunk *gExplosionSound = NULL;
Mix_Chunk *gItemSound = NULL;

// --- �����ܼ� (�C������޲z) ---
Player* gpPlayer = NULL;
Boss* gpBoss = NULL;
std::vector<Enemy*> gEnemies;
std::vector<Bullet*> gBullets;
std::vector<Magnifier*> gItems;

// --- �����ܼ� (�C���޿�) ---
GameState gCurrentState = STATE_MENU;
LevelStage gLevelStage = STAGE_1;
int gEnemiesDefeated = 0;
int gScore = 0;
std::vector<std::string> gDialogues; // 儲存當前要顯示的對話串
int gCurrentDialogueIndex = 0;
bool gEnemySpawned = false; // 用於追蹤教學敵人是否已生成
bool gItemSpawned = false;
// --- �禡�ŧi ---
bool init();
bool loadMedia();
void close();
void resetGame();

// =============================================================
// �D�{��
// =============================================================

int main(int argc, char* args[])
{
    // 1. ��l�ƶüƺؤl
    srand((unsigned)time(NULL));

    // 2. ��l�� SDL
    if( !init() ) {
        printf( "Failed to initialize!\n" );
        return -1;
    }

    // 3. ���J�C��
    if( !loadMedia() ) {
        printf( "Failed to load media!\n" );
        return -1;
    }

    // 4. �إߥD������ (���ɯ��z�w���J)
    gpPlayer = new Player(&gPlayerFront, &gPlayerLeft, &gPlayerRight);

    // ����I������
    Mix_PlayMusic( gMusic, -1 );

    bool quit = false;
    SDL_Event e;
    SDL_Color textColor = { 255, 255, 255 }; // �զ��r

    // --- �C���D�j�� ---
    while( !quit )
    {
        // --- �ƥ�B�z ---
        while( SDL_PollEvent( &e ) != 0 )
        {
            if( e.type == SDL_QUIT ) quit = true;

            // �ھڪ��A�B�z����
            switch(gCurrentState)
            {
                case STATE_MENU:
                    if (e.type == SDL_KEYDOWN) {
                        if (e.key.keysym.sym == SDLK_RETURN) { // Enter �}�l
                            resetGame();
                            gCurrentState = STATE_DIALOGUE;
                        }
                        else if (e.key.keysym.sym == SDLK_i) { // I �ݻ���
                            gCurrentState = STATE_INSTRUCTION;
                        }
                    }
                    break;

                case STATE_INSTRUCTION:
                    if (e.type == SDL_KEYDOWN) {
                        if (e.key.keysym.sym == SDLK_b || e.key.keysym.sym == SDLK_ESCAPE) {
                            gCurrentState = STATE_MENU;
                        }
                    }
                    break;
                case STATE_DIALOGUE:
                    if (e.type == SDL_KEYDOWN) {
                        if (e.key.keysym.sym == SDLK_RETURN) {
                            gCurrentDialogueIndex++;

                            // 檢查是否還有下一句
                            if (gCurrentDialogueIndex >= gDialogues.size()) {
                                // 對話結束，切換到下一個流程階段
                                gDialogues.clear();
                                gCurrentDialogueIndex = 0;

                                // 依據當前階段，進入下一個狀態/觸發事件
                                switch(gLevelStage) {
                                    case STAGE_TUTORIAL_INTRO:
                                        // 介紹結束 -> 進入遊玩模式，並設定下一個目標：第一個敵人
                                        gCurrentState = STATE_PLAYING;
                                        gLevelStage = STAGE_TUTORIAL_ENEMY_FIRST;
                                        break;

                                    case STAGE_TUTORIAL_ENEMY_FIRST:
                                        // 敵人介紹結束 -> 進入遊玩模式，等待敵人被擊敗
                                        gCurrentState = STATE_PLAYING;
                                        break;

                                    case STAGE_TUTORIAL_ITEM_FIRST:
                                        // 道具介紹結束 -> 進入正式遊戲 STAGE_1
                                        gCurrentState = STATE_PLAYING;
                                        gLevelStage = STAGE_1;
                                        break;

                                    default:
                                        // 遊戲中間如果有其他對話，結束後直接回到 PLAYING
                                        gCurrentState = STATE_PLAYING;
                                        break;
                                }
                            }
                        }
                    }
                    break;
                case STATE_PLAYING:
                    gpPlayer->handleEvent(e);

                    // �o�g�l�u
                    if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_SPACE) {
                        std::vector<Bullet*> newShots = gpPlayer->fire(&gBulletTexture);
                        gBullets.insert(gBullets.end(), newShots.begin(), newShots.end());
                        Mix_PlayChannel( -1, gLaserSound, 0 );
                    }
                    // �Ȱ��Φ^���� (�i��)
                    if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_ESCAPE) {
                        gCurrentState = STATE_MENU;
                    }
                    break;

                case STATE_GAME_OVER:
                case STATE_WIN:
                    if (e.type == SDL_KEYDOWN) {
                        if (e.key.keysym.sym == SDLK_r) { // R ����
                            resetGame();
                            gCurrentState = STATE_PLAYING;
                        }
                    }
                    break;
            }
        }

        // --- �޿��s (Update) ---
        if (gCurrentState == STATE_PLAYING)
        {
            // 1. ��s�D��
            gpPlayer->move();
            gpPlayer->updateScatterStatus();

            // 2. �ͦ��P��s�ĤH/Boss (���d�y�{)
            switch (gLevelStage)
            {case STAGE_TUTORIAL_INTRO:
                    // 此階段在 STATE_DIALOGUE 結束後直接跳轉到 STAGE_TUTORIAL_ENEMY_FIRST，此處應為空
                    break;

                case STAGE_TUTORIAL_ENEMY_FIRST:
                    // 只有在這個階段，發送第一個敵人 (如果還沒發送)
                    if (!gEnemySpawned) {
                        gEnemies.push_back(new Enemy(SCREEN_WIDTH/2 - 30, -60, &gEnemyTexture1, &gEnemyTexture2, &gEnemyTexture3));
                        gEnemySpawned = true;
                    }

                    // 當第一個敵人被擊敗時 (假設 gEnemiesDefeated 從 0 變成 1)
                    if (gEnemiesDefeated == 1) {
                        // 設定下一個對話：介紹敵人
                        gDialogues.push_back("恭喜！這是你的第一個擊殺！");
                        gDialogues.push_back("注意，敵人也會發射子彈。");
                        gCurrentDialogueIndex = 0;
                        gCurrentState = STATE_DIALOGUE; // 進入對話狀態
                        gLevelStage = STAGE_TUTORIAL_ITEM_FIRST; // 設定下一流程
                    }
                    break;

                case STAGE_TUTORIAL_ITEM_FIRST:
                    // 在敵人介紹完後，發送道具 (只需要發送一次，如果還沒發送)
                    if (!gItemSpawned && gEnemies.empty()) { // 確保敵人已清空
                        gItems.push_back(new Magnifier(SCREEN_WIDTH/2 - 20, SCREEN_HEIGHT/4));
                        gItemSpawned = true;

                        // 設定道具介紹對話
                        gDialogues.push_back("一個強化道具出現了 (藍色物體)！");
                        gDialogues.push_back("拾取它，你將在短時間內獲得散射射擊能力！");
                        gCurrentDialogueIndex = 0;
                        gCurrentState = STATE_DIALOGUE; // 進入對話狀態
                    }

                    // 檢查玩家是否吃到道具 (如果道具列表為空且玩家有散射效果)
                    if (gItemSpawned && gItems.empty() && gpPlayer->getScatterTimeLeft() > 0) {
                        // 道具介紹和拾取成功 -> 進入正式遊戲 STAGE_1 的對話介紹
                        gDialogues.push_back("強化成功！現在你已經掌握了基本戰鬥技巧。");
                        gDialogues.push_back("遊戲正式開始！祝你好運！");
                        gCurrentDialogueIndex = 0;
                        gCurrentState = STATE_DIALOGUE; // 再次進入對話狀態，對話結束後會跳轉到 STAGE_1
                    }
                    break;
                case STAGE_1:
                    if (rand() % 60 == 0) { // �ͦ��ĤH�W�v
                        gEnemies.push_back(new Enemy(rand() % (SCREEN_WIDTH - 60), -60, &gEnemyTexture1, &gEnemyTexture2, &gEnemyTexture3));
                    }
                    if (gEnemiesDefeated >= 10) {
                        gLevelStage = BOSS_1_FIGHT;
                        gpBoss = new Boss((SCREEN_WIDTH-100)/2, -100, &gBossTexture, 1);
                    }
                    break;

                case BOSS_1_FIGHT:
                case BOSS_2_FIGHT:
                    // Boss �Ԥ��ͦ��p�L
                    break;

                case STAGE_2:
                    if (rand() % 40 == 0) { // �ͦ�����
                        gEnemies.push_back(new Enemy(rand() % (SCREEN_WIDTH - 60), -60, &gEnemyTexture1, &gEnemyTexture2, &gEnemyTexture3));
                    }
                    if (gEnemiesDefeated >= 25) { // �ֿn����
                        gLevelStage = BOSS_2_FIGHT;
                        gpBoss = new Boss((SCREEN_WIDTH-100)/2, -100, &gBossTexture, 2);
                    }
                    break;
            }
            if (gpPlayer->getHealth() <= 0) {
                gCurrentState = STATE_GAME_OVER;
            }
            // ��s Boss
            if (gpBoss) {
                gpBoss->move();
                std::vector<Bullet*> bShots = gpBoss->fire(&gEnemyBulletTexture);
                if (!bShots.empty()) gBullets.insert(gBullets.end(), bShots.begin(), bShots.end());

                if (gpBoss->isDead()) {
                    Mix_PlayChannel(-1, gExplosionSound, 0);
                    delete gpBoss;
                    gpBoss = NULL;

                    if (gLevelStage == BOSS_1_FIGHT) gLevelStage = STAGE_2;
                    else if (gLevelStage == BOSS_2_FIGHT) gCurrentState = STATE_WIN;
                }
            }

            // 3. ��s�ĤH & �H�����_
            for (int i = 0; i < gEnemies.size(); i++) {
                gEnemies[i]->move();
                std::vector<Bullet*> eShots = gEnemies[i]->fire(&gEnemyBulletTexture);
                if (!eShots.empty()) gBullets.insert(gBullets.end(), eShots.begin(), eShots.end());

                if (gEnemies[i]->isOffScreen() || gEnemies[i]->isDead()) {
                    if (gEnemies[i]->isDead()) {
                        gEnemiesDefeated++;
                        gScore += 100;
                        Mix_PlayChannel(-1, gExplosionSound, 0);

                        // �����D�� (20% ���v)
                        if (rand() % 5 == 0) {
                             // �D��ͦ��b�ĤH���`��m
                             // �Y Magnifier �غc�l���ݭn�y�СA�h�� gItems.push_back(new Magnifier());
                             // �Y�ڭ̧�^�ݭn�y�Ъ�����:
                             gItems.push_back(new Magnifier(gEnemies[i]->getPosX(), gEnemies[i]->getPosY()));
                        }
                    }
                    delete gEnemies[i];
                    gEnemies.erase(gEnemies.begin() + i);
                    i--;
                }
            }

            // 4. ��s�l�u�P�I���˴�
            for (int i = 0; i < gBullets.size(); i++) {
                gBullets[i]->move();
                SDL_Rect bRect = gBullets[i]->getCollider();
                bool hit = false;

                // �D���l�u vs �ĤH/Boss
                if (gBullets[i]->getIsFromPlayer()) {
                    // ���ĤH
                    for (auto& e : gEnemies) {
                        SDL_Rect eRect = e->getCollider();
                        if (SDL_HasIntersection(&bRect, &eRect)) {
                            e->takeDamage(1);
                            hit = true;
                            break;
                        }
                    }
                    // �� Boss
                    if (!hit && gpBoss) {
                        SDL_Rect bossRect = gpBoss->getCollider();
                        if (SDL_HasIntersection(&bRect, &bossRect)) {
                            gpBoss->takeDamage(1);
                            hit = true;
                        }
                    }
                }
                // �ĤH�l�u vs �D��
                else {
                    SDL_Rect pRect = gpPlayer->getCollider();
                    if (SDL_HasIntersection(&bRect, &pRect)) {
                        gpPlayer->takeDamage(1);
                        hit = true;
                        // �i�H�[���˭���
                    }
                }

                if (hit) gBullets[i]->setHit();

                if (gBullets[i]->isOffScreen() || !gBullets[i]->isAvailable()) {
                    delete gBullets[i];
                    gBullets.erase(gBullets.begin() + i);
                    i--;
                }
            }

            // 5. ��s�D��
            SDL_Rect pRect = gpPlayer->getCollider();
            for (int i = 0; i < gItems.size(); i++) {
                gItems[i]->move();
                SDL_Rect itemRect = gItems[i]->getCollider();

                // �Y��D��
                if (SDL_HasIntersection(&pRect, &itemRect)) {
                    gpPlayer->activateScatter();
                    gItems[i]->setTaken();
                    Mix_PlayChannel(-1, gItemSound, 0);
                }

                if (!gItems[i]->isAvailable()) {
                    delete gItems[i];
                    gItems.erase(gItems.begin() + i);
                    i--;
                }
            }

            // 6. �ˬd�D���ͦ�
            if (gpPlayer->getHealth() <= 0) {
                gCurrentState = STATE_GAME_OVER;
            }
        }

        // --- ��V (Render) ---

        // �M���e�� (�¦�I��)
        SDL_SetRenderDrawColor( gRenderer, 0x00, 0x00, 0x00, 0xFF );
        SDL_RenderClear( gRenderer );

        if (gCurrentState == STATE_MENU) {
            gMenuTexture.render(0, 0);
        }
        else if (gCurrentState == STATE_INSTRUCTION) {
            gInstructionTexture.render(0, 0);
        }
        else if (gCurrentState == STATE_PLAYING || gCurrentState == STATE_DIALOGUE) {
    // 渲染遊戲畫面
            gBGTexture.render(0, 0);
            gpPlayer->render();
            if (gpBoss) gpBoss->render();
            for (auto e : gEnemies) e->render();
            for (auto b : gBullets) b->render();
            for (auto item : gItems) item->render();

    // 渲染 UI
    std::stringstream timeText;
    timeText << "Score: " << gScore << "  HP: " << gpPlayer->getHealth();
    // 這裡的 gScoreTextTexture 應該是臨時變量或在 LTexture 外部定義
    gScoreTextTexture.loadFromRenderedText(timeText.str().c_str(), textColor, gFont, gRenderer);
    gScoreTextTexture.render(10, 10);

    // 【新增】如果處於對話狀態，渲染對話框和文字
    if (gCurrentState == STATE_DIALOGUE) {
        // 1. 繪製半透明背景 (暫停提示)
        SDL_SetRenderDrawBlendMode(gRenderer, SDL_BLENDMODE_BLEND);
        SDL_SetRenderDrawColor(gRenderer, 0x00, 0x00, 0x00, 0xC0); // 黑色，透明度 75%
        SDL_Rect pause_rect = {0, 0, SCREEN_WIDTH, SCREEN_HEIGHT};
        SDL_RenderFillRect(gRenderer, &pause_rect);

        SDL_SetRenderDrawBlendMode(gRenderer, SDL_BLENDMODE_NONE);

        // 2. 渲染對話框底圖 (如果有 gDialogueBox 紋理)
        int dialog_h = 200; // 原始高度 (200 像素)
        int dialog_y = SCREEN_HEIGHT - dialog_h - 20;

        // ----------------------------------------------------
        // 👇 調整這裡的數值來改變大小和比例 👇
        // ----------------------------------------------------

        // 調整高度 (例如：將高度增加 50%)
        dialog_h = 300; // 現在高度是 300 像素
        dialog_y = SCREEN_HEIGHT - dialog_h - 20; // 重新計算 y 座標以保持底部距離

        // 調整寬度 (例如：讓寬度只佔螢幕的 80%)
        int dialog_w = SCREEN_WIDTH * 0.15;
        int dialog_x = (SCREEN_WIDTH - dialog_w) / 2 - 500;
        if (gDialogueBox.getWidth() > 0) {
            gDialogueBox.render(dialog_x, dialog_y, dialog_w, dialog_h);
        } else {
            // 如果沒有對話框圖片，手動繪製一個框
            SDL_SetRenderDrawColor(gRenderer, 0x33, 0x33, 0x33, 0xFF);
            SDL_Rect box_rect = {dialog_x, dialog_y, dialog_w, dialog_h};
            SDL_RenderFillRect(gRenderer, &box_rect);
        }

        // 3. 渲染當前對話內容
        if (gCurrentDialogueIndex < gDialogues.size()) {
            LTexture dialogueTextTexture;
            std::string fullText = gDialogues[gCurrentDialogueIndex] + " (按 ENTER)";

            int padding_x = 30; // 內邊距，距離左邊 30 像素
            int padding_y = 50; // 內邊距，距離底部 50 像素

            // 計算 x 座標：從對話框的左邊緣 (dialog_x) 加上內邊距 (padding_x)
            int text_x = dialog_x + padding_x;

            // 計算 y 座標：從對話框的底部 (dialog_y + dialog_h) 向上減去文字高度
            //              再減去內邊距 (padding_y)
            int text_y = (dialog_y + dialog_h) - dialogueTextTexture.getHeight() - padding_y;

            dialogueTextTexture.render(
                text_x, // 新的 X 座標：左邊緣 + 內邊距
                text_y
            );
        }
    }
}
        else if (gCurrentState == STATE_GAME_OVER) {

            // 1. 渲染 Game Over 圖片 (全屏)
            gGameOverTexture.render(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
            SDL_Color promptColor = { 255, 255, 255 };

            // 2. 渲染最終得分 (Final Score)
            std::stringstream finalScore;
            finalScore << "Final Score: " << gScore;

            // 使用 gScoreTextTexture 渲染得分
            gScoreTextTexture.loadFromRenderedText(finalScore.str().c_str(), promptColor, gFont, gRenderer);

            // 渲染最終得分文本 (居中)
            gScoreTextTexture.render(
                (SCREEN_WIDTH - gScoreTextTexture.getWidth()) / 2,
                SCREEN_HEIGHT/2 + 50
            );

            // 3. 渲染重新開始提示
            std::string restartPrompt = "Press R to Restart";
            LTexture promptTexture; // 使用一個臨時 LTexture 來渲染提示文本

            promptTexture.loadFromRenderedText(restartPrompt.c_str(), promptColor, gFont, gRenderer);

            // 渲染提示文本 (居中)
            promptTexture.render(
                (SCREEN_WIDTH - promptTexture.getWidth()) / 2,
                SCREEN_HEIGHT/2 + 100
            );
        }
        // 接下來是 STATE_WIN 的邏輯
        else if (gCurrentState == STATE_WIN) {
            // ... (您的 STATE_WIN 邏輯) ...
        }        SDL_RenderPresent( gRenderer );
    }

    // ����귽�ðh�X
    close();
    return 0;
}

// =============================================================
// ���U�禡��@
// =============================================================

bool init()
{
    if( SDL_Init( SDL_INIT_VIDEO | SDL_INIT_AUDIO ) < 0 ) return false;

    // �]�w�u�ʹL�o
    if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) ) {}

    gWindow = SDL_CreateWindow( "Space Shooter", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
    if( gWindow == NULL ) return false;

    gRenderer = SDL_CreateRenderer( gWindow, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC );
    if( gRenderer == NULL ) return false;

    SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );

    // IMG Init
    int imgFlags = IMG_INIT_PNG;
    if( !( IMG_Init( imgFlags ) & imgFlags ) ) return false;

    // TTF Init
    if( TTF_Init() == -1 ) return false;

    // Mixer Init
    if( Mix_OpenAudio( 44100, MIX_DEFAULT_FORMAT, 2, 2048 ) < 0 ) return false;

    return true;
}

bool loadMedia()
{
    bool success = true;

    // Jr (載入字體)
    // gFont = TTF_OpenFont( "BoutiqueBitmap9x9_1.92.ttf", 28 ); // 請確認字體檔名和路徑
    // if( gFont == NULL ) {
    //     printf("Failed to load font! SDL_ttf Error: %s\n", TTF_GetError() );
    //     success = false;
    // }

    // 載入對話框背景
    if( !gDialogueBox.loadFromFile( "dialogue_box.png", gRenderer ) ) {
        // 如果沒有圖片，這裡可能失敗，但我們會在渲染時繪製一個替代框
        // printf("Failed to load dialogue_box.png. Using default box.\n");
    }
    // ���J�r��
    // gFont = TTF_OpenFont( "BoutiqueBitmap9x9_1.92.ttf", 28 );
    // if( gFont == NULL ) { printf("Failed to load font!\n"); success = false; }

    // ���J�����Ϥ� (�Цۦ�ǳƳo�ǹϤ�)
    if( !gMenuTexture.loadFromFile( "menu.png", gRenderer ) ) success = false;
    if( !gInstructionTexture.loadFromFile( "instruction.png", gRenderer ) ) success = false;
    if( !gGameOverTexture.loadFromFile( "gameover.png", gRenderer ) ) success = false;
    // gWinTexture.loadFromFile("win.png", gRenderer); // �i��
    // gBGTexture.loadFromFile("bg.png", gRenderer);   // �i��

    // ���J����Ϥ�
    if( !gPlayerFront.loadFromFile( "player.png", gRenderer ) ) success = false;
    if( !gPlayerLeft.loadFromFile( "player_left.png", gRenderer ) ) success = false;
    if( !gPlayerRight.loadFromFile( "player_right.png", gRenderer ) ) success = false;

    //if( !gEnemyTexture.loadFromFile( "enemy.png", gRenderer ) ) success = false;
    if( !gEnemyTexture1.loadFromFile( "enemy_1.png", gRenderer ) ) success = false;
    if( !gEnemyTexture2.loadFromFile( "enemy_2.png", gRenderer ) ) success = false;
    if( !gEnemyTexture3.loadFromFile( "enemy_3.png", gRenderer ) ) success = false;
    if( !gBossTexture.loadFromFile( "boss.png", gRenderer ) ) success = false;
    if( !gBulletTexture.loadFromFile( "bullet_player.png", gRenderer ) ) success = false;
    if( !gEnemyBulletTexture.loadFromFile( "bullet_enemy.png", gRenderer ) ) success = false;
    if( !gMagnifierTexture.loadFromFile( "magnifier.png", gRenderer ) ) success = false;

    // ���J����
    gMusic = Mix_LoadMUS( "bgm.mp3" );
    gLaserSound = Mix_LoadWAV( "laser.wav" );
    gExplosionSound = Mix_LoadWAV( "explosion.wav" );
    gItemSound = Mix_LoadWAV( "item.wav" ); // ���]�A���o��

    return success;
}

void close()
{
    // ���񪫥�
    if(gpPlayer) delete gpPlayer;
    if(gpBoss) delete gpBoss;
    for(auto e : gEnemies) delete e;
    for(auto b : gBullets) delete b;
    for(auto i : gItems) delete i;

    // ���񯾲z
    gPlayerFront.free();
    gPlayerLeft.free();
    gPlayerRight.free();
    gEnemyTexture1.free();
    gEnemyTexture2.free();
    gEnemyTexture3.free();
    gBossTexture.free();
    gBulletTexture.free();
    gEnemyBulletTexture.free();
    gMagnifierTexture.free();
    gMenuTexture.free();
    gInstructionTexture.free();
    gGameOverTexture.free();
    gScoreTextTexture.free();
    gHealthTextTexture.free();

    // ���񭵮�
    Mix_FreeMusic( gMusic );
    Mix_FreeChunk( gLaserSound );
    Mix_FreeChunk( gExplosionSound );
    Mix_FreeChunk( gItemSound );

    // ���� SDL �l�t��
    TTF_CloseFont( gFont );
    SDL_DestroyRenderer( gRenderer );
    SDL_DestroyWindow( gWindow );

    Mix_Quit();
    TTF_Quit();
    IMG_Quit();
    SDL_Quit();
}

void resetGame()
{
    // ���m���d�ƭ�
    gEnemiesDefeated = 0;
    gScore = 0;
    gLevelStage = STAGE_TUTORIAL_INTRO;
    // ���m�D�� (�o�̰��] Player ���O����@ reset)
    // �p�G�S���A�A�]�i�H�b�o�� delete gpPlayer; gpPlayer = new Player(...);
    if(gpPlayer) {
        // ²�檺�覡�G�������m��m�M��q
        // �p�G�A�� Player ���O�S�� reset()�A�аO�o�[�W�h
        // gpPlayer->reset();

        // �Ϊ̤�ʭ��m�G
        delete gpPlayer;
    }

    // �M�żĤH�B�l�u�B�D��BBoss
    gpPlayer = new Player(&gPlayerFront, &gPlayerLeft, &gPlayerRight);

    // MżĤHBluBDBBoss
    // ... (原有清理程式碼保持不變) ...

    gEnemySpawned = false;
    gItemSpawned = false;

    // 【新增】設定第一個對話 (遊戲介紹)
    gDialogues.clear();
    gDialogues.push_back("歡迎來到太空射擊遊戲！");
    gDialogues.push_back("使用方向鍵移動，空白鍵射擊。");
    gDialogues.push_back("按 Enter 繼續下一句對話。");
    gCurrentDialogueIndex = 0;
}
