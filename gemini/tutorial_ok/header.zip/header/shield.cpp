#include "shield.h"

ShieldItem::ShieldItem(int x, int y, bool stopAtMiddle)
{
    mPosX = x;
    mPosY = y;
    mVelY = 2; // �����t��
    available = true;
    mStopAtMiddle = stopAtMiddle;
}

void ShieldItem::move()
{
    // �p�G�O�оǼҦ��B��F�����A�N����
    if (mStopAtMiddle && mPosY >= 200) {
        // ����
    } else {
        mPosY += mVelY;
    }

    // ����ˬd
    if (mPosY > SCREEN_HEIGHT) {
        available = false;
    }
}

void ShieldItem::render()
{
    if (available) {
        gShieldItemTexture.render(mPosX, mPosY);
    }
}

SDL_Rect ShieldItem::getCollider()
{
    SDL_Rect r;
    r.x = mPosX; r.y = mPosY;
    r.w = WIDTH; r.h = HEIGHT;
    return r;
}
